﻿using System;
using System.Globalization;


namespace Com.Cognizant.Truyum.Utility
{
    public class DateUtil
    {
        public static DateTime ConvertToShortDate(string date)
        {
            DateTime dt = DateTime.ParseExact(date, "dd/MM/yyyy", null);
            
                return dt;
            
           

        }
    }
}
