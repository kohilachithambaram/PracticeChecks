﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Truyum.Dao;
using System.Globalization;
using System.Threading;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            lblMessage.Text = "";
            DisplayItems();
        }
    }

    protected void gridItem_AddbuttonClick(object sender, GridViewCommandEventArgs e)
    {
        //Find the row number for which or whose button u are clicking
        int gridviewrowindex = int.Parse(e.CommandArgument.ToString());
        //thrroug row number extract item id
        string itemId = gridItem.Rows[gridviewrowindex].Cells[0].Text;

        CartDaoCollection cartDao = new CartDaoCollection();

        cartDao.AddCartItem(1, long.Parse(itemId));
        lblMessage.Text = "Item Added To the Cart Successfully";
    }

    protected void DisplayItems()
    {
        MenuItemDaoCollection menuCollection = new MenuItemDaoCollection();
        List<Com.Cognizant.Truyum.Model.MenuItem> menuList = menuCollection.GetMenuItemListCustomer();
        gridItem.DataSource = menuList;
        gridItem.DataBind();
    }

    protected override void InitializeCulture()
    {
        CultureInfo ci = new CultureInfo("en-IN");
        ci.NumberFormat.CurrencySymbol = "₹";
        Thread.CurrentThread.CurrentCulture = ci;

        base.InitializeCulture();
    }
}