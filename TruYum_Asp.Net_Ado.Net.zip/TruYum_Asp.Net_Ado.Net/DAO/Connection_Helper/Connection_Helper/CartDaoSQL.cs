﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//class file
//namespace
using System.Data;
using System.Data.SqlClient;
//namespace for model
using Com.Cognizant.Truyum.Model;

namespace DAO
{
    public class CartDaoSQL
    {
        static string callConnection = ConnectionHandler.ConnectionVariable;
        public static string addCartData = "insert into cart values(@userId,@menuId);";
        public static string getAllCartItems = "select * from menu_item as me join cart as ct on me.me_id = ct.ct_me_id where ct.ct_us_id = @userId;";
        public static string countTotal = "select sum(me.me_price) as Total from menu_item as me join cart as ct on me.me_id = ct.ct_me_id where ct.ct_us_id = @userId;";
        public static string deleteItem = "delete from cart where ct_us_id = @userId and ct_me_id = @menuId;";

        public static void AddCartItem(long userId,long productId)
        {
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = addCartData
                };

                cmd.Parameters.Add("@userId",SqlDbType.Int).Value = userId;
                cmd.Parameters.Add("@menuId", SqlDbType.Int).Value = productId;

                cmd.ExecuteNonQuery();
            }
        }

        public static Cart GetAllCartItems(long userId)
        {
            Cart cart = new Cart();
            List<MenuItem> menuList = new List<MenuItem>();

            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = getAllCartItems
                };

                cmd.Parameters.Add("@userId", SqlDbType.Int).Value = userId;

                SqlDataReader dr = cmd.ExecuteReader();
                int count = 0;

                while (dr.Read())
                {
                    MenuItem menu = new MenuItem();
                    menu.Id = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("me_id")));
                    menu.Name = Convert.ToString(dr.GetValue(dr.GetOrdinal("me_name")));
                    menu.Price = Convert.ToSingle(dr.GetValue(dr.GetOrdinal("me_price")));
                    menu.Active = Convert.ToString(dr.GetValue(dr.GetOrdinal("me_active"))).Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false;
                    menu.DateOfLaunch = Convert.ToDateTime(dr.GetValue(dr.GetOrdinal("me_date_of_launch")));
                    menu.Category = Convert.ToString(dr.GetValue(dr.GetOrdinal("me_category")));
                    menu.FreeDelivery = (Convert.ToString(dr.GetValue(dr.GetOrdinal("me_free_delivery"))).Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false);
                    count++;
                    menuList.Add(menu);
                }
                //dr.Close();
                if(count == 0) // ie no item in the cart
                {
                    throw new CartEmptyException("Exception:No item in the Cart");
                }

                cart.MenuItemList = menuList;
                dr.Close();

                SqlCommand cmd1 = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = countTotal
                };

                cmd1.Parameters.Add("@userId", SqlDbType.Int).Value = userId;

                SqlDataReader dr1 = cmd1.ExecuteReader();

                while(dr1.Read())
                {
                    cart.Total = Convert.ToDouble(dr1.GetValue(dr1.GetOrdinal("Total")));
                }

            }

            return cart;
        }

        public static void RemoveCartItem(long userId,long productId)
        {
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = deleteItem
                };

                cmd.Parameters.Add("@userId", SqlDbType.Int).Value = userId;
                cmd.Parameters.Add("@menuId", SqlDbType.Int).Value = productId;

                cmd.ExecuteNonQuery();
            }
        }
    }
}
