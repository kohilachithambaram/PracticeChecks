﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//class file
//namespace
using System.Data;
using System.Data.SqlClient;
//namespace for model
using Com.Cognizant.Truyum.Model;
namespace DAO
{
    public class MenuItemDaoSQL
    {
        static string callConnection = ConnectionHandler.ConnectionVariable;
        static string getDataAdmin = "select * from menu_item as me;";
        static string getDataCustomer = "select * from menu_item as me where me.me_date_of_launch > GETDATE() and me.me_active = 'Yes';";
        static string getItemById = "select * from menu_item as me where me.me_id = @id;";
        static string updateItem = "update menu_item set me_name = @name, me_price = @price, me_active = @active, me_date_of_launch = @dateOfLaunch, me_category = @category, me_free_delivery = @freeDelivery where me_id = @id;";

        public static List<MenuItem> GetMenuItemListAdmin()
        {
            List<MenuItem> menuList = new List<MenuItem>();
            

            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = getDataAdmin
                };

                SqlDataReader dr = cmd.ExecuteReader();

                while(dr.Read())
                {
                    MenuItem menu = new MenuItem();
                    menu.Id = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("me_id")));
                    menu.Name = Convert.ToString(dr.GetValue(dr.GetOrdinal("me_name")));
                    menu.Price = Convert.ToSingle(dr.GetValue(dr.GetOrdinal("me_price")));
                    menu.Active = Convert.ToString(dr.GetValue(dr.GetOrdinal("me_active"))).Equals("yes",StringComparison.InvariantCultureIgnoreCase) ? true : false;
                    menu.DateOfLaunch = Convert.ToDateTime(dr.GetValue(dr.GetOrdinal("me_date_of_launch")));
                    menu.Category = Convert.ToString(dr.GetValue(dr.GetOrdinal("me_category")));
                    menu.FreeDelivery = (Convert.ToString(dr.GetValue(dr.GetOrdinal("me_free_delivery"))).Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false);

                    menuList.Add(menu);
                }
            }

            return menuList;
        }

        public static List<MenuItem> GetMenuItemListCustomer()
        {
            List<MenuItem> menuList = new List<MenuItem>();


            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = getDataCustomer
                };

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    MenuItem menu = new MenuItem();
                    menu.Id = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("me_id")));
                    menu.Name = Convert.ToString(dr.GetValue(dr.GetOrdinal("me_name")));
                    menu.Price = Convert.ToSingle(dr.GetValue(dr.GetOrdinal("me_price")));
                    menu.Active = Convert.ToString(dr.GetValue(dr.GetOrdinal("me_active"))).Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false;
                    menu.DateOfLaunch = Convert.ToDateTime(dr.GetValue(dr.GetOrdinal("me_date_of_launch")));
                    menu.Category = Convert.ToString(dr.GetValue(dr.GetOrdinal("me_category")));
                    menu.FreeDelivery = (Convert.ToString(dr.GetValue(dr.GetOrdinal("me_free_delivery"))).Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false);

                    menuList.Add(menu);
                }
            }

            return menuList;
        }

        public static void ModifyMenuItem(MenuItem menuItem)
        {
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = updateItem
                };

                cmd.Parameters.Add("@name",SqlDbType.VarChar).Value = menuItem.Name;
                cmd.Parameters.Add("@price", SqlDbType.Decimal).Value = menuItem.Price;
                cmd.Parameters.Add("@active", SqlDbType.VarChar).Value = (menuItem.Active == true) ? "Yes" : "No";
                cmd.Parameters.Add("@dateOfLaunch", SqlDbType.Date).Value = menuItem.DateOfLaunch;
                cmd.Parameters.Add("@category", SqlDbType.VarChar).Value = menuItem.Category;
                cmd.Parameters.Add("@freeDelivery", SqlDbType.VarChar).Value = (menuItem.FreeDelivery == true) ? "Yes" : "No";
                cmd.Parameters.Add("@id", SqlDbType.Int).Value = menuItem.Id;

                cmd.ExecuteNonQuery();
            }
        }

        public static MenuItem GetMenuItem(long menuItemId)
        {
            MenuItem menuItem = new MenuItem();
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = getItemById
                };
                cmd.Parameters.Add("@id",SqlDbType.Int).Value = menuItemId;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    menuItem.Id = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("me_id")));
                    menuItem.Name = Convert.ToString(dr.GetValue(dr.GetOrdinal("me_name")));
                    menuItem.Price = Convert.ToSingle(dr.GetValue(dr.GetOrdinal("me_price")));
                    menuItem.Active = Convert.ToString(dr.GetValue(dr.GetOrdinal("me_active"))).Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false;
                    menuItem.DateOfLaunch = Convert.ToDateTime(dr.GetValue(dr.GetOrdinal("me_date_of_launch")));
                    menuItem.Category = Convert.ToString(dr.GetValue(dr.GetOrdinal("me_category")));
                    menuItem.FreeDelivery = (Convert.ToString(dr.GetValue(dr.GetOrdinal("me_free_delivery"))).Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false);
                }
            }
            return menuItem;
        }
    }
}
