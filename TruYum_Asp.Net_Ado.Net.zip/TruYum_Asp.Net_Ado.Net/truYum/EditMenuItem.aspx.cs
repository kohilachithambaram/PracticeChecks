﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAO;
using Com.Cognizant.Truyum.Utility;


public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            lblId.Text = Request.QueryString["ItemId"].ToString();
            /*txtName.Text= Request.QueryString["Name"].ToString();
            txtPrice.Text= Request.QueryString["Price"].ToString(); ;
            txtDateOfLaunch.Text= Request.QueryString["Date Of Launch"].ToString();*/

            ddlCategory.Items.Add("Select Item");
            ddlCategory.Items.Add("Main Course");
            ddlCategory.Items.Add("Starters");
            ddlCategory.Items.Add("Desserts");
            ddlCategory.Items.Add("Drinks");

            if(lblId.Text!=null ||lblId.Text!="")//i.e id is found
            {
                Com.Cognizant.Truyum.Model.MenuItem menu = MenuItemDaoSQL.GetMenuItem(long.Parse(lblId.Text));

                //Fill  the data in the controls through menu class properties
                txtName.Text = menu.Name;
                txtPrice.Text = menu.Price.ToString();
                txtDateOfLaunch.Text = menu.DateOfLaunch.ToString("dd/MM/yyyy");

                //check if the menuItem is having active yes or no
                if(menu.Active==true)
                {
                    radioActive.Checked = true;
                }
                else
                {
                    radioInactive.Checked = true;
                }

                //Check if free delivery is given
                chkFreeDelivery.Checked = menu.FreeDelivery;


                //Item present by admin in dropdown
                ddlCategory.SelectedItem.Text=menu.Category;
            }
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        //Save the edit info back to collection
        Com.Cognizant.Truyum.Model.MenuItem menu = new Com.Cognizant.Truyum.Model.MenuItem();
        menu.Id = long.Parse(lblId.Text);
        menu.Name = txtName.Text;
        menu.Price = long.Parse(txtPrice.Text);
        menu.DateOfLaunch = DateUtil.ConvertToShortDate(txtDateOfLaunch.Text);
        menu.Category = ddlCategory.SelectedItem.Text;
        if(radioActive.Checked==true)
        {
            radioInactive.Checked = false;
            menu.Active = true;
        }
        else
        {
            radioInactive.Checked = true;
            menu.Active = false;
        }
        if(chkFreeDelivery.Checked==true)
        {
            menu.FreeDelivery = true;
        }
        else
        {
            menu.FreeDelivery = false;
        }
        //call the modify method
        MenuItemDaoSQL.ModifyMenuItem(menu);
        Response.Redirect("EdiMenuItemStatus.aspx");
    }

    protected void radioActive_CheckedChanged(object sender, EventArgs e)
    {
        if(radioActive.Checked==true)
        {
            radioInactive.Checked = false;
        }
    }

    protected void radioInactive_CheckedChanged(object sender, EventArgs e)
    {
        if (radioInactive.Checked == true)
        {
            radioActive.Checked = false;
        }
    }
}