function validate()
{
var title = document.Edit_form.title.value;
var price = document.Edit_form.price.value;
var dateOfLaunch = document.Edit_form.dateOfLaunch.value;
var category = document.Edit_form.category.value;

if(title == null || title=="" )
{
alert('Title is required');
return false;
}

if(title.length<2 || title.length>65)
{
alert('Title should have 2 to 65 characters');
return false;
}

if(isNaN(price))
{
alert('Price has to be a number');
return false;
}

if(price == null || price=="" )
{
alert('Price is required');
return false;
}

if(dateOfLaunch == null || dateOfLaunch == "" )
{
alert('Date Of Launch is required');
return false;
}

var date_pattern=/^(0[1-9]|[12][0-9]|3[01])[\- \/.](?:(0[1-9]|1[012])[\- \/.](19|20)[0-9]{2})$/;
if(!dateOfLaunch.match(date_pattern))
{
alert('Date Of Launch must be in DD/MM/YYYY format');
return false;
} 

if(category == null || category == "" )
{
alert('Select one category');
return false;
}

else
{
return true;
}

}

function check_radio()
{
if(document.getElementById("active_yes").checked==true)
{
alert("Yes Active");
}
if(document.getElementById("active_no").checked==true) 
{
alert("Not Active");
}
}

function check_option()
{
if(document.getElementById("freeDelivery").checked==true)
{
alert("Free Delivery available");
}
else
{
alert("Free Delivery not available");
}
}
