﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Com.Cognizant.Truyum.Dao;
using Com.Cognizant.Truyum.Model;
using Com.Cognizant.Truyum.Utility;
namespace TruYumConsole
{
    class CartDaoCollectionTest
    {
        public CartDaoCollectionTest()
        {
            TestAddcartItem();
            TestRemoveCartItem();
        }

        public static void TestAddcartItem()
        {
            Console.WriteLine("\nAdd new item to cart");
            CartDaoCollection cartDao = new CartDaoCollection();
            cartDao.AddCartItem(1, 1001);
            try
            {
                TestGetAllCartItem();
            }
            catch (CartEmptyException e)
            {
                Console.WriteLine(e);
            }
            /*cartDao.AddCartItem(2, 1002);
          cartDao.AddCartItem(1, 1005);*/
        }
        public static void TestGetAllCartItem()
        {
            CartDaoCollection cartDao = new CartDaoCollection();
            Cart cart = cartDao.GetAllCartItems(1);
            Console.WriteLine("\nName       FreeDelivery      Price");
            for (int i = 0; i < cart.MenuItemList.Count; i++)
            {
                Console.WriteLine(cart.MenuItemList[i].Name + "     " + cart.MenuItemList[i].FreeDelivery + "             " + cart.MenuItemList[i].Price + "\n Total:  " + cart.Total);
            }

        }
        public static void TestRemoveCartItem()
        {

            Console.WriteLine("\nRemove data from cart");
            CartDaoCollection cartDao = new CartDaoCollection();
            cartDao.RemoveCartItem(1, 1001);
            try
            {
                TestGetAllCartItem();
            }
            catch (CartEmptyException e)
            {
                Console.WriteLine(e);
            }

        }
    }
}
