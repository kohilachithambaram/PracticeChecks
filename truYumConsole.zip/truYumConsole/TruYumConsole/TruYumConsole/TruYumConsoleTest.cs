﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TruYumConsole
{
    class TruYumConsoleTest
    {
        static void Main(string[] args)
        {
            int menu = 0;

            Console.WriteLine("1.Item Information\n2.Cart Information\n3.Exit");
            do
            {
                menu = int.Parse(Console.ReadLine());
                switch (menu)
                {
                    case 1:
                        MenuItemDaoCollectionTest menuTest = new MenuItemDaoCollectionTest();
                        break;

                    case 2:
                        CartDaoCollectionTest cartTest = new CartDaoCollectionTest();
                        break;
                    case 3:
                        Environment.Exit(0);
                        break;
                }
                
                        Console.WriteLine("Do you want to continue(1 or 2)");
                  
                        Console.WriteLine("1.Item Information\n2.Cart Information\n3.Exit");
                

            } while (menu!=3);
        }
    }
}
