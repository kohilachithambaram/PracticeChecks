-- Include table data insertion, updation, deletion and select scripts
use truyum;

/*1.View Menu Item List Admin*/
insert into menu_item values('Sandwich',99.00,'Yes','03/15/2017','Main Course','Yes'),
('Burger', 129.00,'Yes','12/23/2017', 'Main Course','No'),
('Pizza',149.00,'Yes','08/21/2018', 'Main Course','No'),
('French Fries', 57.00,'No','07/02/2017', 'Starters','Yes'),
('Chocholate Brownie', 32.00,'Yes','11/02/2022', 'Dessert','Yes');

select me.me_name as Name,me.me_price as Price,me.me_active as Active,me.me_date_of_launch as [Date Of Launch],me.me_category as Category,me.me_free_delivery as [Free Delivery] 
from menu_item as me;

/*2.View Menu Item List Customer*/
select me.me_name as Name,me.me_free_delivery as [Free Delivery],me.me_price as Price,me.me_category as Category
from menu_item as me 
where me.me_date_of_launch > GETDATE() and me.me_active = 'Yes';

/*3.Edit Menu Item */
select me.me_name as Name,me.me_price as Price,me.me_active as Active,me.me_date_of_launch as [Date Of Launch],me.me_category as Category,me.me_free_delivery as [Free Delivery]
from menu_item as me where me.me_id = 3;

update menu_item set
me_name = 'Momos',
me_price = 50.00,
me_active = 'No',
me_date_of_launch = '09/15/2023',
me_category = 'Starters',
me_free_delivery = 'Yes' 
where me_id = 3;

/*4.Add to Cart */
insert into [user] values ('Admin'),('Customer');

insert into cart values(2,1),
(2,3),
(2,5);


/*5.View Cart */
select me.me_name as Name,me.me_free_delivery as [Free Delivery],me.me_price as Price 
from menu_item as me 
join cart as ct 
on me.me_id = ct.ct_me_id
where ct.ct_us_id = 2;

select sum(me.me_price) as Total
from menu_item as me 
join cart as ct 
on me.me_id = ct.ct_me_id
where ct.ct_us_id = 2;

/*6.Remove Item from Cart */
delete from cart where ct_us_id = 2 and ct_me_id = 5; 

select * from menu_item;
